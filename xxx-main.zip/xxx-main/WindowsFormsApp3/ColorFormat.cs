﻿// This is a personal academic project. Dear PVS-Studio, please check it.

// PVS-Studio Static Code Analyzer for C, C++, C#, and Java: https://pvs-studio.com

using System;
using System.Drawing;

namespace WindowsFormsApp3
{


    public class ColorFormat
    {
        public Color Color { get; set; }
        public Color Color1 { get; set; }
        public Predicate<DateTime> Predicate { get; set; }
        public Predicate<DateTime> Predicate1 { get; set; }
    }

    public class ColorFormat1
    {
        public Color Color { get; set; }
        public Predicate<DateTime> Predicate1 { get; set; }
    }

}
